#include <iostream>

#include "ShaderMaker.h"
#include "Lib.h"
#include "geometria.h"
#include "GestioneTesto.h"
#include <ft2build.h>
#include FT_FREETYPE_H
#include "objloader.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

int width = 1024;
int height = 800;
int width_i = 400;
int height_i = 400;

int w_up = width;
int h_up = height;
mat4 Projection_text;
string stringa_asse;
string Operazione;
int idfg, idfi;
  
static unsigned int programId, programId_text,programId1, MatrixProj, MatrixProjS, MatrixProj_txt, MatModel, MatModelS, MatView, MatViewS, loc_time,lsh, leye,lscelta, loc_view_pos;
unsigned int VAO_Text, VBO_Text, programIdr, texture2;
unsigned int MatModelR, MatViewR, MatrixProjR, loc_view_posR, loc_cubemapR;

vec3 asse = vec3(0.0, 1.0, 0.0);
 
int selected_obj = -1;
Mesh Cubo, Piano, Piramide, Centri, Sfera;
static vector<Material> materials;
static vector<Shader> shaders;

point_light light;

//Puntatori alle variabili uniformi per l'impostazione dell'illuminazione

LightShaderUniform light_unif = {};


const float sphere_radius = 3.0f;
static bool moving_trackball = 0;
static int last_mouse_pos_Y;
static int last_mouse_pos_X;
#define BUFFER_OFFSET(i) ((char *)NULL + (i))
float cameraSpeed=0.05;
mat4 Projection, Model, View;
enum {
	NAVIGATION,
	CAMERA_MOVING,
	TRASLATING,
	ROTATING,
	SCALING
} OperationMode;
enum {
	X,
	Y,
	Z
} WorkingAxis;

typedef enum {
	WIRE_FRAME,
	FACE_FILL,
	CULLING_ON,
	CULLING_OFF,
}MenuOption;

float deltaTime = 0.0f;	// Time between current frame and last frame
float lastFrame = 0.0f; // Time of last frame

unsigned int idTex, cubemapTexture, texture, texture1;

//MATERIALI DI BASE

glm::vec3 red_plastic_ambient = { 0.1, 0.0, 0.0 }, red_plastic_diffuse = { 0.6, 0.1, 0.1 }, red_plastic_specular = { 0.7, 0.6, 0.6 }; GLfloat red_plastic_shininess = 150.0f;
glm::vec3 brass_ambient = { 0.1, 0.06, 0.015 }, brass_diffuse = { 0.78, 0.57, 0.11 }, brass_specular = { 0.99, 0.91, 0.81 }; GLfloat brass_shininess = 27.8f;
glm::vec3 emerald_ambient = { 0.0215, 0.04745, 0.0215 }, emerald_diffuse = { 0.07568, 0.61424, 0.07568 }, emerald_specular = { 0.633, 0.727811, 0.633 }; GLfloat emerald_shininess = 78.8f;
glm::vec3 slate_ambient = { 0.02, 0.02, 0.02 }, slate_diffuse = { 0.1, 0.1, 0.1 }, slate_specular{ 0.4, 0.4, 0.4 }; GLfloat slate_shininess = 1.78125f;
glm::vec3 yellow_ambient = { 0.8,	0.8,	0.0 }, yellow_diffuse = { 0.5,0.5,0.4 }, yellow_specular{ 0.9,	0.9	,0.04 }; GLfloat yellow_shininess = 1.78125f;
glm::vec3 rosa_ambient = { 0.05f,0.0f,0.0f }, rosa_diffuse = { 0.5f,0.4f,0.4f }, rosa_specular{ 0.7f,0.04f,0.04f }; GLfloat rosa_shininess = 1.78125f;
glm::vec3 marrone_ambient = { 0.19125f, 0.0735f, 0.0225f }, marrone_diffuse = { 0.7038f, 0.27048f, 0.0828f }, marrone_specular{ 0.256777f, 0.137622f, 0.086014f }; GLfloat marrone_shininess = 12.8f;


float angolo = 0.0;


vector<std::string> faces
{
	"right.jpg",
	"left.jpg",
	"top.jpg",
	"bottom.jpg",
	"front.jpg",
	"back.jpg"
	
};
 
// loads a cubemap texture from 6 individual texture faces
// order:
// +X (right)
// -X (left)
// +Y (top)
// -Y (bottom)
// +Z (front) 
// -Z (back)
//

unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}

void genera_texture(void)
{

	glGenTextures(1, &texture);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, texture);
	// set the texture wrapping/filtering options (on the currently bound texture object)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load and generate the texture
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(1);
	stbi_uc* data = stbi_load("muromattoni.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		GLenum format;
		if (nrChannels == 3)
			format = GL_RGB;

		if (nrChannels == 4)
			format = GL_RGBA;
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		printf("Tutto OK %d %d \n", width, height);
	}
	else
	{
		printf("Errore nel caricare la texture n. 1\n");
	}
	stbi_image_free(data);


	glGenTextures(1, &texture1);
	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, texture1);
	// set the texture wrapping/filtering options (on the currently bound texture object)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load and generate the texture

	data = stbi_load("minnie.png", &width, &height, &nrChannels, 0);
	stbi_set_flip_vertically_on_load(1);
	if (data)
	{
		GLenum format;
		if (nrChannels == 3)
			format = GL_RGB;

		if (nrChannels == 4)
			format = GL_RGBA;

		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		printf("Errore nel caricare la texture 2\n");
	}
	stbi_image_free(data);


}

unsigned int loadCubemap(vector<std::string> faces)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

	int width, height, nrChannels;
	for (unsigned int i = 0; i < faces.size(); i++)
	{
		unsigned char* data = stbi_load(faces[i].c_str(), &width, &height, &nrChannels, 0);
		if (data)
		{
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i,
				0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data
			);
			stbi_image_free(data);
		}
		else
		{
			std::cout << "Cubemap tex failed to load at path: " << faces[i] << std::endl;
			stbi_image_free(data);
		}
	}
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

	return textureID;
}

void update(int a)
{
	angolo += 0.1;
	glutTimerFunc(10, update, 0);
	
	glutSetWindow(idfi);
	glutPostRedisplay();
	
	
	glutSetWindow(idfg);
	glutPostRedisplay();
	
}

void INIT_SHADER(void)

{
	GLenum ErrorCheckValue = glGetError();

	char* vertexShader = (char*)"vertexShader_C.glsl";
	char* fragmentShader = (char*)"fragmentShader_C.glsl";

	programId = ShaderMaker::createProgram(vertexShader, fragmentShader);
	glUseProgram(programId);

	//Generazione del program shader per la gestione del testo
	vertexShader = (char*)"VertexShader_Text.glsl";
	fragmentShader = (char*)"FragmentShader_Text.glsl";

	programId_text = ShaderMaker::createProgram(vertexShader, fragmentShader);

	vertexShader = (char*)"vertexShader_CubeMap.glsl";
	fragmentShader = (char*)"fragmentShader_CubeMap.glsl";

	programId1 = ShaderMaker::createProgram(vertexShader, fragmentShader);


	vertexShader = (char*)"vertexShader_riflessione.glsl";
	fragmentShader = (char*)"fragmentShader_riflessione.glsl";

	programIdr = ShaderMaker::createProgram(vertexShader, fragmentShader);

}

void crea_VAO_Vector(Mesh* mesh)
{

	glGenVertexArrays(1, &mesh->VAO);
	glBindVertexArray(mesh->VAO);
	//Genero , rendo attivo, riempio il VBO della geometria dei vertici
	glGenBuffers(1, &mesh->VBO_G);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->VBO_G);
	glBufferData(GL_ARRAY_BUFFER, mesh->vertici.size() * sizeof(vec3), mesh->vertici.data(), GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(0);

	//Genero , rendo attivo, riempio il VBO dei colori
	glGenBuffers(1, &mesh->VBO_C);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->VBO_C);
	glBufferData(GL_ARRAY_BUFFER, mesh->colori.size() * sizeof(vec4), mesh->colori.data(), GL_STATIC_DRAW);
	//Adesso carico il VBO dei colori nel layer 2
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(1);

	glGenBuffers(1, &mesh->VBO_normali);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->VBO_normali);
	glBufferData(GL_ARRAY_BUFFER, mesh->normali.size() * sizeof(vec3), mesh->normali.data(), GL_STATIC_DRAW);
	//Adesso carico il VBO delle NORMALI nel layer 2
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(2);

	 
	glGenBuffers(1, &mesh->VBO_coord_texture);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->VBO_coord_texture);
	glBufferData(GL_ARRAY_BUFFER, mesh->texCoords.size() * sizeof(vec2), mesh->texCoords.data(), GL_STATIC_DRAW);
	//Adesso carico il VBO delle NORMALI nel layer 2
	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(3);
 
	//EBO di tipo indici
	glGenBuffers(1, &mesh->EBO_indici);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->EBO_indici);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh->indici.size() * sizeof(GLuint), mesh->indici.data(), GL_STATIC_DRAW);


}

void INIT_VAO(void)
{
	cubemapTexture = loadCubemap(faces);

	Mesh Panchina, Acero, Cavallo, Coniglio, Piano, Sfera1, Cono1, Sky, Cubo, Cottage, Airplane;
	string MeshDir = "Meshes/";
	vec3 cx;

	//Sky
	
	crea_cubo(&Sky, vec4(1.0, 0.0, 0.0,1.0), vec4(0.1, 1.0, 0.0, 1.0));
	crea_VAO_Vector(&Sky);
	Scena.push_back(Sky);
	
	crea_piano(&Piano, vec4(1.0, 0.0, 0.0, 1.0));
	crea_VAO_Vector(&Piano);
	Piano.nome = "Piano";
	Piano.Model = mat4(1.0);
	Piano.Model = translate(Piano.Model, vec3(.0, +8.0, -20.0));
	Piano.Model = scale(Piano.Model, vec3(15.0f, 8.0f, 1.0f));
	Piano.Model = rotate(Piano.Model, radians(90.0f), vec3(1.0, 0.0, 0.0));
	Piano.Model = rotate(Piano.Model, radians(45.0f), vec3(0.0, 1.0, 0.0));
	cx = Piano.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(cx);
	raggi.push_back(0.5);
	Piano.sceltaVS = 1;
	Piano.material = MaterialType::EMERALD;
	Scena.push_back(Piano);
	
	bool obj;
	
	obj=loadOBJ(MeshDir + "cottageScarno.obj", Panchina);
	crea_VAO_Vector(&Panchina);
	Panchina.nome = "Cottage";
	
	Panchina.Model = mat4(1.0);
	Panchina.Model = translate(Panchina.Model, vec3(-10.0, 5.0, 1.0));
	Panchina.Model = rotate(Panchina.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));
	Panchina.Model = scale(Panchina.Model, vec3(1.5f, 1.5f, 1.0f));
	cx = Panchina.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Panchina.sceltaVS = 1;
	Panchina.material = MaterialType::SLATE;
	Scena.push_back(Panchina);
	
	
	Panchina.Model = mat4(1.0);
	Panchina.Model = translate(Panchina.Model, vec3(+10.0f, 0.0f, -10.0f));
	Panchina.Model = rotate(Panchina.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));
	
	cx = Panchina.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Panchina.sceltaVS = 1;
	Panchina.material = MaterialType::SLATE;
	Scena.push_back(Panchina);
	


	obj = loadOBJ(MeshDir + "cottageScarno.obj", Cottage);
	crea_VAO_Vector(&Cottage);
	Cottage.nome = "Cottage_1";
	Cottage.Model = mat4(1.0);

	Cottage.Model = rotate(Cottage.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));
	cx = Cottage.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Cottage.sceltaVS = 1;
	Cottage.material = MaterialType::EMERALD;
	Scena.push_back(Cottage);

	Cottage.Model = mat4(1.0);
	Cottage.Model = translate(Cottage.Model, vec3(+10.0f, 0.0f, -10.0f));
	Cottage.Model = rotate(Cottage.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));

	cx = Cottage.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Cottage.sceltaVS = 1;
	Cottage.material = MaterialType::ROSA;
	Scena.push_back(Cottage);
	

	obj = loadOBJ(MeshDir + "cottageScarno.obj", Cottage);
	crea_VAO_Vector(&Cottage);
	Cottage.nome = "Cottage_1";
	Cottage.Model = mat4(1.0);

	Cottage.Model = rotate(Cottage.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));
	cx = Cottage.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Cottage.sceltaVS = 1;
	Cottage.material = MaterialType::EMERALD;
	Scena.push_back(Cottage);

	Cottage.Model = mat4(1.0);
	Cottage.Model = translate(Cottage.Model, vec3(+10.0f, 0.0f, -10.0f));
	Cottage.Model = rotate(Cottage.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));

	cx = Cottage.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Cottage.sceltaVS = 1;
	Cottage.material = MaterialType::ROSA;
	Scena.push_back(Cottage);


	/*Acero*/
	obj=loadOBJ(MeshDir + "acero.obj", Acero);
	crea_VAO_Vector(&Acero);
	Acero.nome = "Acero";
	Acero.Model = mat4(1.0);
	Acero.Model = translate(Acero.Model, vec3(6.0f, 0.0f, -18.0f));
	Acero.Model = scale(Acero.Model, vec3(4.0f, 8.0f, 4.0f));
	cx = Acero.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Acero.sceltaVS = 1;
	Acero.material = MaterialType::BRASS;
	Scena.push_back(Acero);

	obj = loadOBJ(MeshDir + "acero.obj", Acero);
	crea_VAO_Vector(&Acero);
	Acero.nome = "Acero";
	Acero.Model = mat4(1.0);
	Acero.Model = translate(Acero.Model, vec3(-6.0f, 0.0f, -18.0f));
	Acero.Model = scale(Acero.Model, vec3(4.0f, 8.0f, 4.0f));
	cx = Acero.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Acero.sceltaVS = 1;
	Acero.material = MaterialType::BRASS;
	Scena.push_back(Acero);

	/*Cavalli*/
	obj=loadOBJ(MeshDir + "horse_n_t_smooth.obj", Cavallo);
	crea_VAO_Vector(&Cavallo);
	Cavallo.nome = "Cavallo";
	Cavallo.Model = mat4(1.0);
	Cavallo.Model = translate(Cavallo.Model, vec3(16.0f, 1.0f, -8.0f));

	cx = Cavallo.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Cavallo.sceltaVS = 1;
	Cavallo.material = MaterialType::MARRONE;
	Scena.push_back(Cavallo);

	Cavallo.Model = mat4(1.0);
	Cavallo.Model = translate(Cavallo.Model, vec3(-16.0f, 1.0f, -8.0f));
	Cavallo.Model = rotate(Cavallo.Model, radians(180.0f), vec3(0.0, 1.0, 0.0));
	Cavallo.sceltaVS = 1;
	Cavallo.material = MaterialType::SLATE;
	Scena.push_back(Cavallo);

	/*Aeroplano*/
	obj = loadOBJ(MeshDir + "airplane.obj", Airplane);
	crea_VAO_Vector(&Airplane);
	Airplane.nome = "Airplane";
	Airplane.Model = mat4(1.0);
	Airplane.Model = translate(Airplane.Model, vec3(.0f, .0f, -2.0f));
	Airplane.Model = scale(Airplane.Model, vec3(5.0f));

	cx = Airplane.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Airplane.sceltaVS = 1;
	Airplane.material = MaterialType::ROSA;
	Scena.push_back(Airplane);


	/*Coniglio*/
	obj=loadOBJ(MeshDir + "bunny_n_t_smooth.obj", Coniglio);
	crea_VAO_Vector(&Coniglio);
	Coniglio.nome = "Coniglio";
	Coniglio.Model = mat4(1.0);
	Coniglio.Model = translate(Coniglio.Model, vec3(-6.0f, -0.5f, 1.5f));

	cx = Coniglio.Model * vec4(0.0, 0.0, 0.0, 1.0);
	centri.push_back(vec3(cx));
	raggi.push_back(1.0);
	Coniglio.sceltaVS = 1;
	Coniglio.material = MaterialType::ROSA;
	Scena.push_back(Coniglio);
 
	 }

void INIT_Illuminazione()
	 {
	light.position = { 0.0,10.0,0.0 };
	light.color = { 1.0,1.0,1.0 };
	light.power = 2.f;

	//Setup dei materiali
	// Materials setup
	materials.resize(8);
	materials[MaterialType::RED_PLASTIC].name = "Red Plastic";
	materials[MaterialType::RED_PLASTIC].ambient = red_plastic_ambient;
	materials[MaterialType::RED_PLASTIC].diffuse = red_plastic_diffuse;
	materials[MaterialType::RED_PLASTIC].specular = red_plastic_specular;
	materials[MaterialType::RED_PLASTIC].shininess = red_plastic_shininess;

	materials[MaterialType::EMERALD].name = "Emerald";
	materials[MaterialType::EMERALD].ambient = emerald_ambient;
	materials[MaterialType::EMERALD].diffuse = emerald_diffuse;
	materials[MaterialType::EMERALD].specular = emerald_specular;
	materials[MaterialType::EMERALD].shininess = emerald_shininess;

	materials[MaterialType::BRASS].name = "Brass";
	materials[MaterialType::BRASS].ambient = brass_ambient;
	materials[MaterialType::BRASS].diffuse = brass_diffuse;
	materials[MaterialType::BRASS].specular = brass_specular;
	materials[MaterialType::BRASS].shininess = brass_shininess;

	materials[MaterialType::SLATE].name = "Slate";
	materials[MaterialType::SLATE].ambient = slate_ambient;
	materials[MaterialType::SLATE].diffuse = slate_diffuse;
	materials[MaterialType::SLATE].specular = slate_specular;
	materials[MaterialType::SLATE].shininess = slate_shininess;

	materials[MaterialType::YELLOW].name = "Yellow";
	materials[MaterialType::YELLOW].ambient = yellow_ambient;
	materials[MaterialType::YELLOW].diffuse = yellow_diffuse;
	materials[MaterialType::YELLOW].specular = yellow_specular;
	materials[MaterialType::YELLOW].shininess = yellow_shininess;

	materials[MaterialType::ROSA].name = "ROSA";
	materials[MaterialType::ROSA].ambient = rosa_ambient;
	materials[MaterialType::ROSA].diffuse = rosa_diffuse;
	materials[MaterialType::ROSA].specular = rosa_specular;
	materials[MaterialType::ROSA].shininess = rosa_shininess;

	materials[MaterialType::MARRONE].name = "MARRONE";
	materials[MaterialType::MARRONE].ambient = marrone_ambient;
	materials[MaterialType::MARRONE].diffuse = marrone_diffuse;
	materials[MaterialType::MARRONE].specular = marrone_specular;
	materials[MaterialType::MARRONE].shininess = marrone_shininess;
	materials[MaterialType::NO_MATERIAL].name = "NO_MATERIAL";
	materials[MaterialType::NO_MATERIAL].ambient = glm::vec3(1, 1, 1);
	materials[MaterialType::NO_MATERIAL].diffuse = glm::vec3(0, 0, 0);
	materials[MaterialType::NO_MATERIAL].specular = glm::vec3(0, 0, 0);
	materials[MaterialType::NO_MATERIAL].shininess = 1.f;

	//Setup degli shader
	shaders.resize(5);
	shaders[ShaderOption::NONE].value = 0;
	shaders[ShaderOption::NONE].name = "NONE";
	shaders[ShaderOption::GOURAD_SHADING].value = 1;
	shaders[ShaderOption::GOURAD_SHADING].name = "GOURAD SHADING";
	shaders[ShaderOption::PHONG_SHADING].value = 2;
	shaders[ShaderOption::PHONG_SHADING].name = "PHONG SHADING";
	shaders[ShaderOption::ONDE_SHADING].value = 3;
	shaders[ShaderOption::ONDE_SHADING].name = "ONDE SHADING";
	shaders[ShaderOption::BANDIERA_SHADING].value = 4;
	shaders[ShaderOption::BANDIERA_SHADING].name = "BANDIERA SHADING";

}

void INIT_VAO_Text(void)
{

	// configure VAO/VBO for texture quads
	// -----------------------------------
	glGenVertexArrays(1, &VAO_Text);
	glGenBuffers(1, &VBO_Text);
	glBindVertexArray(VAO_Text);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_Text);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void moveCameraUp()
{
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	vec3 direzione_scorrimento = glm::cross(vec3(ViewSetup.direction), glm::vec3(ViewSetup.upVector));
	ViewSetup.position += vec4(.0, (direzione_scorrimento)) * cameraSpeed;
	ViewSetup.target += vec4(.0, (direzione_scorrimento)) * cameraSpeed;
}


void moveCameraDown()
{
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	vec3 direzione_scorrimento = glm::cross(vec3(ViewSetup.direction), glm::vec3(ViewSetup.upVector));
	ViewSetup.position -= vec4(.0, (direzione_scorrimento)) * cameraSpeed;
	ViewSetup.target -= vec4(.0, (direzione_scorrimento)) * cameraSpeed;
}

void moveCameraForward()
{
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	ViewSetup.position += ViewSetup.direction * cameraSpeed;

}

void moveCameraBack()
{
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	ViewSetup.position -= ViewSetup.direction * cameraSpeed;

}

void moveCameraLeft()
{
	//Calcolo la direzione perpendicolare alla direzione della camera e l'alto della camera
		// e muovo la camera a sinistra lungo questa direzione
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	vec3 direzione_scorrimento = glm::cross(vec3(ViewSetup.direction), glm::vec3(ViewSetup.upVector));
	ViewSetup.position -= vec4((direzione_scorrimento), .0) * cameraSpeed;
	ViewSetup.target -= vec4((direzione_scorrimento), .0) * cameraSpeed;
}

void moveCameraRight()
{
	//Calcolo la direzione perpendicolare alla direzione della camera e l'alto della camera
	// e muovo la camera a destra lungo questa direzione
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	vec3 direzione_scorrimento = glm::cross(vec3(ViewSetup.direction), glm::vec3(ViewSetup.upVector)) * cameraSpeed;
	ViewSetup.position += vec4(direzione_scorrimento, 0);
	ViewSetup.target += vec4(direzione_scorrimento, 0);
}

void modifyModelMatrix(glm::vec3 translation_vector, glm::vec3 rotation_vector, GLfloat angle, GLfloat scale_factor)
{
	//ricordare che mat4(1) costruisce una matrice identit� di ordine 4
	mat4 traslation = glm::translate(glm::mat4(1), translation_vector);
	mat4 scale = glm::scale(glm::mat4(1), glm::vec3(scale_factor, scale_factor, scale_factor));
	mat4 rotation = glm::rotate(glm::mat4(1), angle, rotation_vector);

	//Modifica la matrice di Modellazione dell'oggetto della scena selezionato postmolitplicando per le matrici scale*rotation*traslation

	if (selected_obj > -1)
	{
		Scena[selected_obj].Model = Scena[selected_obj].Model * scale * rotation * traslation;
		centri[selected_obj] = centri[selected_obj] + translation_vector;
		raggi[selected_obj] = raggi[selected_obj] * scale_factor;
	}

}

void keyboardPressedEvent(unsigned char key, int x, int y)
{
	switch (key)
	{
		case 'a':
			moveCameraLeft();
			break;
		case 'd':
			moveCameraRight();
			break;

		case 'w':
			moveCameraForward();
			break;

		case 's':
			moveCameraBack();
			break;
	
		case 'u':
			moveCameraUp();
			break;

		case 'j':
			moveCameraDown();
			break;
	
		default:
			break;
	}

}

	
void INIT_CAMERA_PROJECTION(void)
{
	//Imposto la telecamera
	ViewSetup = {};
	ViewSetup.position = glm::vec4(0.0, 0.5, 25.0, 0.0);
	ViewSetup.target = glm::vec4(0.0, 0.0, 0.0, 0.0);
	ViewSetup.direction = ViewSetup.target - ViewSetup.position;
	ViewSetup.upVector = glm::vec4(0.0, 1.0, 0.0, 0.0);


	//Imposto la proiezione prospettica
	PerspectiveSetup = {};
	PerspectiveSetup.aspect = (GLfloat)width / (GLfloat)height;
	PerspectiveSetup.fovY = 45.0f;
	PerspectiveSetup.far_plane = 2000.0f;
	PerspectiveSetup.near_plane = 0.1f;
}


void resize(int w, int h)
{
	glViewport(0, 0, w, h);
	PerspectiveSetup.aspect = (GLfloat)w / (GLfloat)h;
	Projection = perspective(radians(PerspectiveSetup.fovY), PerspectiveSetup.aspect, PerspectiveSetup.near_plane, PerspectiveSetup.far_plane);
	w_up = w;
	h_up = h;
}

void drawScene(void)
{
	 
	float time = glutGet(GLUT_ELAPSED_TIME)/1000.0;

	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//Passo al Vertex Shader il puntatore alla matrice Projection, che sar� associata alla variabile Uniform mat4 Projection
	//all'interno del Vertex shader. Uso l'identificatio MatrixProj
	glm::mat4 Projection = glm::perspective(PerspectiveSetup.fovY, PerspectiveSetup.aspect, PerspectiveSetup.near_plane, PerspectiveSetup.far_plane);
	glm::mat4 View = glm::lookAt(glm::vec3(ViewSetup.position), vec3(ViewSetup.target), glm::vec3(ViewSetup.upVector));


	//MONDO
	//--------------------------------
	//Disegno SKY per primo


	glDepthMask(GL_FALSE);
	glUseProgram(programId1);
	glUniform1i(glGetUniformLocation(programId1, "skybox"), 0);
	glUniformMatrix4fv(MatrixProjS, 1, GL_FALSE, value_ptr(Projection));

	glUniformMatrix4fv(MatViewS, 1, GL_FALSE, value_ptr(View));
	// skybox cube
	glBindVertexArray(Scena[0].VAO);
	glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
	glDrawElements(GL_TRIANGLES, Scena[0].indici.size() * sizeof(GLuint), GL_UNSIGNED_INT, 0);

	glBindVertexArray(0);
	glDepthMask(GL_TRUE);

	glUseProgram(programId);
	glUniformMatrix4fv(MatrixProj, 1, GL_FALSE, value_ptr(Projection));

	//Costruisco la matrice di Vista che applicata ai vertici in coordinate del mondo li trasforma nel sistema di riferimento della camera.

	   
	//Passo al Vertex Shader il puntatore alla matrice View, che sar� associata alla variabile Uniform mat4 Projection
	//all'interno del Vertex shader. Uso l'identificatio MatView


	glUseProgram(programIdr);
	 
	glUniformMatrix4fv(MatrixProjR, 1, GL_FALSE, value_ptr(Projection));
	glUniformMatrix4fv(MatModelR, 1, GL_FALSE, value_ptr(Scena[1].Model));
	glUniformMatrix4fv(MatViewR, 1, GL_FALSE, value_ptr(View));
	glUniform3f(loc_view_posR, ViewSetup.position.x, ViewSetup.position.y, ViewSetup.position.z);
	glBindVertexArray(Scena[1].VAO);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
	glDrawElements(GL_TRIANGLES, (Scena[1].indici.size() - 1) * sizeof(GLuint), GL_UNSIGNED_INT, 0);

	glBindVertexArray(0);

	glUseProgram(programId);
	glPointSize(10.0);
	glUniformMatrix4fv(MatView, 1, GL_FALSE, value_ptr(View));

	//Definizione colore luce, posizione ed intensit�
	glUniform3f(light_unif.light_position_pointer, light.position.x + 50 * cos(radians(angolo)), light.position.y, light.position.z + 50 * sin(radians(angolo)));
	glUniform3f(light_unif.light_color_pointer, light.color.r, light.color.g, light.color.b);
	glUniform1f(light_unif.light_power_pointer, light.power);

	//Passo la posizione della camera
	glUniform3f(loc_view_pos, ViewSetup.position.x, ViewSetup.position.y, ViewSetup.position.z);
	glUniform1f(loc_time, time);
	for (int k =2; k <Scena.size(); k++)
	{
		 
		glUniformMatrix4fv(MatModel, 1, GL_FALSE, value_ptr(Scena[k].Model));
		glUniform1i(lscelta, Scena[k].sceltaVS);
		
		
		glUniform3fv(light_unif.material_ambient, 1, glm::value_ptr(materials[Scena[k].material].ambient));
		glUniform3fv(light_unif.material_diffuse, 1, glm::value_ptr(materials[Scena[k].material].diffuse));
		glUniform3fv(light_unif.material_specular, 1, glm::value_ptr(materials[Scena[k].material].specular));
		glUniform1f(light_unif.material_shininess, materials[Scena[k].material].shininess);
		glUniform1i(idTex, 0);

		glBindVertexArray(Scena[k].VAO);
		
		if(k<6)
		{
			glBindTexture(GL_TEXTURE_2D, texture1);
			glDrawElements(GL_TRIANGLES, (Scena[k].indici.size() - 1) * sizeof(GLuint), GL_UNSIGNED_INT, 0);
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, texture2);
			glDrawArrays(GL_TRIANGLES, 0, Scena[k].vertici.size());
		}

	
			 
 		glBindVertexArray(0);

	}
	

	glutSwapBuffers();

}


void main_menu_func(int option)
{
	switch (option)
	{
	case MenuOption::WIRE_FRAME: glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		break;
	case MenuOption::FACE_FILL: glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		break;

	default:
		break;
	}
}


void buildOpenGLMenu()
{  
	glutCreateMenu(main_menu_func); // richiama main_menu_func() alla selezione di una voce menu
	glutAddMenuEntry("Wireframe", MenuOption::WIRE_FRAME);
	glutAddMenuEntry("Face fill", MenuOption::FACE_FILL);
	glutAttachMenu(GLUT_MIDDLE_BUTTON);
}

int main(int argc, char* argv[])
{
	glutInit(&argc, argv);

	glutInitContextVersion(4, 0);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);


	//Inizializzo finestra per il rendering della scena 3d con tutti i suoi eventi le sue inizializzazioni e le sue impostazioni
	
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	idfg = glutCreateWindow("Scena 3D");
	glutDisplayFunc(drawScene);
	glutReshapeFunc(resize);
	//glutMouseFunc(mouse);
	glutKeyboardFunc(keyboardPressedEvent);
	glutTimerFunc(10, update, 0);
	//sglutMotionFunc(mouseActiveMotion); // Evento tasto premuto
	glewExperimental = GL_TRUE;
	glewInit();
	INIT_SHADER();
	INIT_VAO();
	INIT_Illuminazione();
	buildOpenGLMenu();
	INIT_CAMERA_PROJECTION();
	glEnable(GL_DEPTH_TEST);
	glCullFace(GL_BACK);
	glCullFace(GL_BACK);

	glEnable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//Chiedo che mi venga restituito l'identificativo della variabile uniform mat4 Projection (in vertex shader).
	//QUesto identificativo sar� poi utilizzato per il trasferimento della matrice Projection al Vertex Shader
	MatrixProj = glGetUniformLocation(programId, "Projection");
	//Chiedo che mi venga restituito l'identificativo della variabile uniform mat4 Model (in vertex shader)
	//QUesto identificativo sar� poi utilizzato per il trasferimento della matrice Model al Vertex Shader
	MatModel = glGetUniformLocation(programId, "Model");
	//Chiedo che mi venga restituito l'identificativo della variabile uniform mat4 View (in vertex shader)
	//QUesto identificativo sar� poi utilizzato per il trasferimento della matrice View al Vertex Shader
	MatView = glGetUniformLocation(programId, "View");
	loc_time = glGetUniformLocation(programId, "time");
	loc_view_pos = glGetUniformLocation(programId, "ViewPos");
	 
	lscelta = glGetUniformLocation(programId, "sceltaVs");
	 
	light_unif.light_position_pointer = glGetUniformLocation(programId, "light.position");
	light_unif.light_color_pointer = glGetUniformLocation(programId, "light.color");
	light_unif.light_power_pointer = glGetUniformLocation(programId, "light.power");
	light_unif.material_ambient = glGetUniformLocation(programId, "material.ambient");
	light_unif.material_diffuse = glGetUniformLocation(programId, "material.diffuse");
	light_unif.material_specular = glGetUniformLocation(programId, "material.specular");
	light_unif.material_shininess = glGetUniformLocation(programId, "material.shininess");
	idTex = glGetUniformLocation(programId, "tex0");


	MatrixProjS = glGetUniformLocation(programId1, "Projection");
	//Chiedo che mi venga restituito l'identificativo della variabile uniform mat4 Model (in vertex shader)
	//QUesto identificativo sar� poi utilizzato per il trasferimento della matrice Model al Vertex Shader


	//Chiedo che mi venga restituito l'identificativo della variabile uniform mat4 Model (in vertex shader)
	//QUesto identificativo sar� poi utilizzato per il trasferimento della matrice Model al Vertex Shader
	MatViewS = glGetUniformLocation(programId1, "View");
	
	
	MatModelR = glGetUniformLocation(programIdr, "Model");
	MatViewR = glGetUniformLocation(programIdr, "View");
	MatrixProjR = glGetUniformLocation(programIdr, "Projection");
	loc_view_posR = glGetUniformLocation(programIdr, "ViewPos");
	loc_cubemapR=glGetUniformLocation(programIdr, "cubemap");
	 
	glutMainLoop();
}

